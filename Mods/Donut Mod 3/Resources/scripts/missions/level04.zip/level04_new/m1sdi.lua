Game.SelectMission("m1sd")
	Game.SetPresentationBitmap("art\\frontend\\dynaload\\images\\mis04_01.p3d")
	Game.SetMissionResetPlayerOutCar("marge_start","current_carstart")
	Game.SetDynaLoadData("map\\l4textures.p3d;l4z1.p3d;l4r1.p3d;l4r7.p3d;l4i02.p3d@", "SimpsonsHouse")
	Game.UsePedGroup(0)

	Game.AddStage(0)
		Game.AddObjective("dummy")
		
		Game.CloseObjective()
	Game.CloseStage()
Game.CloseMission()