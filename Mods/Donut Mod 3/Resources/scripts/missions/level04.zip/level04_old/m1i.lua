if Settings.EnableNewLevel4Map then
	dofile(Mod.Paths.Resources .. "/scripts/missions/level04_new/" .. GetFileName(GetPath()) .. ".lua")
	return -- cancel this script
end

--This mission may or may not be used in the final version of the mod - Chris

Game.SelectMission("m1")
Game.SetMissionResetPlayerOutCar("m6_marge_start","level4_carstart")
Game.SetDynaLoadData("l4z1.p3dl4r1.p3dl4r7.p3d")
Game.UsePedGroup(3)

	Game.AddStage(1) --Go Outside	    
	  	Game.RESET_TO_HERE()
	  	Game.SetStageMusicAlwaysOn()
		Game.SetStageMessageIndex(2)
		Game.AddObjective("gooutside")
			-- Game.SetHUDIcon("simpdoor")
			Game.AddStageVehicle("wiggu_v","m1_wiggum_carstart","NULL","Missions\\l4m1\\M1evade.con", "wiggum")
			Game.SetDestination("m1_police_trigger")
			Game.TurnGotoDialogOff()
		Game.CloseObjective()
	Game.CloseStage()


	Game.AddStage(2) --Follow Chief Wiggum (to Lard Lads)
		Game.SetStageMusicAlwaysOn()
		-- Game.SetHUDIcon("wiggum")
		Game.SetStageMessageIndex(3)

        Game.AddStageVehicle("cDonut", "cDonut_carstart", "NULL", "Missions\\l4m1\\M1evade.con", "male2")
        Game.ActivateVehicle("wiggu_v","NULL","evade")
		-- Game.SetVehicleAIParams("wiggu_v", -10, -9) 		--  <=== name, min, max 0,1 = really dumb, no shortcuts

		Game.AddStageWaypoint("m1_police1")
		Game.AddStageWaypoint("m1_police2")

		Game.AddObjective("follow","neither")
			Game.SetObjTargetVehicle("wiggu_v")
		Game.CloseObjective()

		Game.AddCondition("followdistance")
			Game.SetFollowDistances(0, 120)
			Game.SetCondTargetVehicle("wiggu_v")
		Game.CloseCondition()

		Game.SetIrisWipe(0.1)

	Game.CloseStage()

	Game.AddStage(3)
	Game.SetStageMusicAlwaysOn()
	Game.SetStageMessageIndex(4)
	-- Game.SetHUDIcon( "wiggum" )
	Game.AddObjective("talkto")
		Game.RemoveDriver("wiggum")
		Game.AddStageCharacter ("marge", "m1_marge2", "", "current", "mission1_carstart")
		Game.AddStageVehicle("wiggu_v","m1_cop_stop","NULL","Missions\\l4m1\\M1evade.con")
		Game.AddNPC("wiggum","m1_wiggum_place")	
		Game.SetTalkToTarget("wiggum", 0, 0) -- 0 - eclamation, 1 is gift, with optional hieight offset
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage(4)
	Game.AddObjective("dialogue")
		Game.AmbientAnimationRandomize( 1, 0 )      -- ( pc=0, npc=1) (nonrandom=0, random=1)
		Game.AmbientAnimationRandomize( 0, 0 )
		Game.SetConversationCam( 0, "pc_far" )
		Game.SetConversationCam( 1, "npc_far" )
		Game.AddAmbientNpcAnimation( "none" )
		Game.AddAmbientNpcAnimation( "dialogue_scratch_head" )
		Game.AddAmbientPcAnimation( "dialogue_hands_in_air" )
		Game.AddAmbientPcAnimation( "none" )
		Game.SetCamBestSide("m1_bestside")
		Game.SetDialogueInfo("marge","wiggum","cure",0)
		Game.SetDialoguePositions("m1_wiggum_walk1","m1_wiggum_walk2","m5_carstart")
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage(0)
	Game.SetStageMusicAlwaysOn()
	Game.SetStageMessageIndex(5)
	Game.AddObjective("getin", "neither")
		Game.SetObjTargetVehicle("current")
		Game.CloseObjective()
Game.CloseStage()

Game.AddStage(1)
	Game.SetStageMusicAlwaysOn()
	  -- Game.SetHUDIcon("donuts")
	  Game.SetStageMessageIndex(6)
	  Game.SetStageTime(90)

	  Game.ActivateVehicle("cDonut","NULL","evade")

	  Game.AddStageWaypoint("m1_donut1")
	  Game.AddStageWaypoint("m1_donut2")

	 	Game.AddObjective("dump","neither")
	 	    Game.SetObjTargetVehicle("cDonut")

            for i = 1, ({5,5})[Difficulty.Current], 1 do
				Game.AddCollectible("donut_chocolate"..tostring(i),"donut_chocolate")
			end
       Game.CloseObjective()

		Game.AddCondition("timeout")
		Game.CloseCondition()

		Game.ShowStageComplete()

Game.CloseStage()

Game.AddStage(6)
	Game.SetStageMusicAlwaysOn()
		-- Game.SetHUDIcon("lardlads")
		Game.SetStageMessageIndex(7)
		Game.SetStageTime(90)

			Game.AddObjective("goto")
				Game.SetDestination("m1_police2", "carsphere")
				Game.SetCollectibleEffect("wrench_collect")
			Game.CloseObjective()

	    Game.AddCondition("timeout")
		Game.CloseCondition()
Game.CloseStage()

Game.AddStage(7)
	Game.SetStageMusicAlwaysOn()
	Game.SetStageMessageIndex(4)
	-- Game.SetHUDIcon( "wiggum" )
	Game.AddObjective("talkto")
		Game.AddNPC("wiggum","m1_wiggum_place") 
		Game.AddObjectiveNPCWaypoint( "wiggum", "m1_wiggum_walk1" )
		Game.AddObjectiveNPCWaypoint( "wiggum", "m1_wiggum_walk2" )
		Game.AddObjectiveNPCWaypoint( "wiggum", "m1_wiggum_place" )
		Game.SetTalkToTarget("wiggum", 0, 0) -- 0 - eclamation, 1 is gift, with optional hieight offset
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage(8)
	Game.AddObjective("dialogue")
		Game.AmbientAnimationRandomize( 1, 0 )      -- ( pc=0, npc=1) (nonrandom=0, random=1)
		Game.AmbientAnimationRandomize( 0, 0 )
		Game.SetConversationCam( 0, "pc_far" );
		Game.SetConversationCam( 1, "npc_far" );
		Game.AddAmbientNpcAnimation( "dialogue_scratch_head" )
		Game.AddAmbientNpcAnimation( "none" )
		Game.AddAmbientPcAnimation( "none" )
		Game.AddAmbientPcAnimation( "dialogue_hands_in_air" )
		Game.SetCamBestSide("m1_bestside");
		Game.SetDialogueInfo("marge","wiggum","shack",0)
		Game.SetDialoguePositions("m1_marge","m1_wiggum","m5_carstart",1)
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage(5)
	Game.SetStageMessageIndex(5)
	Game.AddObjective("getin", "neither")
		Game.SetObjTargetVehicle("current")
		Game.CloseObjective()
Game.CloseStage()

Game.AddStage(9)
	Game.SetStageMusicAlwaysOn()
	Game.SetMaxTraffic(3)
	Game.SetStageMessageIndex(8)
	Game.SetStageTime(90)
	-- Game.SetHUDIcon( "cletushs" )

	Game.AddObjective("goto")
		Game.AddStageVehicle("cletu_v","m1_cletu_v_carstart","NULL","Missions\\l4m1\\M2chase.con","cletus")
		Game.SetDestination("m1_cletus_fake")
		Game.SetCollectibleEffect("wrench_collect")

		Game.SetCompletionDialog("decrapitude", "cletus")

	Game.CloseObjective()
Game.CloseStage()

Game.CloseStage()

Game.AddStage(12)
	Game.SetStageMusicAlwaysOn()
	Game.SetMaxTraffic(3) 
	Game.SetStageMessageIndex(10)
	-- Game.SetHUDIcon("cletus_v")

	Game.AddStageWaypoint("m2_waypoint5")

	Game.ActivateVehicle("cletu_v","NULL","evade")
	Game.SetVehicleAIParams("cletu_v", 10, 20)

	Game.AddObjective("follow", "neither")
		Game.SetObjTargetVehicle("cletu_v")
   	Game.CloseObjective()

	Game.AddCondition("followdistance")
		Game.SetFollowDistances(0,200)
		Game.SetCondTargetVehicle("cletu_v")
	Game.CloseCondition()

	Game.SetIrisWipe(0.1)

	Game.ShowStageComplete()

Game.CloseStage()


Game.AddStage(13)
		Game.SetStageMusicAlwaysOn()
		Game.AddObjective("timer")

		Game.AddStageCharacter("marge", "", "", "current", "m2_marge_car2" )

		Game.AddNPC("cletus","m2_cletus_2")

		Game.AddStageVehicle("cletu_v","m2_cletustruck_2","NULL","Missions\\level04\\M2chase.con");

		Game.RemoveDriver("cletus")

		Game.SetDurationTime(1)

	Game.CloseObjective()

Game.CloseStage()

Game.AddStage(15);
	Game.SetStageMusicAlwaysOn()
	Game.SetMaxTraffic(3);
	Game.SetStageMessageIndex(9);
	-- Game.SetHUDIcon( "cletus" );
	
	Game.AddObjective("talkto");
		Game.AddNPC("cletus", "m2_cletus_2");
		Game.SetTalkToTarget("cletus", 0, 0); 
	Game.CloseObjective();

Game.AddStage();
	Game.SetStageMessageIndex(4);
	Game.AddObjective("dialogue");
		Game.AmbientAnimationRandomize( 1, 0 );      -- ( pc=0, npc=1) (nonrandom=0, random=1)
		Game.AmbientAnimationRandomize( 0, 0 );
		Game.SetConversationCam( 0, "pc_far" );
		Game.SetConversationCam( 1, "npc_far" );
		Game.SetConversationCam( 2, "pc_far" );
		Game.AddAmbientNpcAnimation( "none" );
		Game.AddAmbientNpcAnimation( "dialogue_no" );
		Game.AddAmbientNpcAnimation( "none" );
		Game.AddAmbientPcAnimation( "none" );
		Game.AddAmbientPcAnimation( "none" );
		Game.AddAmbientPcAnimation( "dialogue_scratch_head" );
		Game.SetCamBestSide("m3_bestside");
		Game.SetDialogueInfo("marge","cletus","baby",0);
		Game.SetDialoguePositions("m2_marge_talk","m3_cletus_walk1","m2_marge_car2");
	Game.CloseObjective();
Game.CloseStage();	

Game.AddStage(14)
	Game.SetStageMusicAlwaysOn()		
	Game.SetStageMessageIndex(11)
	-- Game.SetHUDIcon("ketchup")
	Game.SetStageTime(90)

		Game.AddObjective("delivery")
			for i = 1, ({20,20})[Difficulty.Current], 1 do
				Game.AddCollectible("ketchup"..tostring(i),"ketchup")
			end
		Game.CloseObjective()

	Game.AddCondition("timeout")
	Game.CloseCondition()

	Game.ShowStageComplete()

Game.CloseStage()

Game.AddStage(15);
	Game.SetStageMusicAlwaysOn()
	Game.SetMaxTraffic(3);
	Game.SetStageMessageIndex(12);
	-- Game.SetHUDIcon( "cletus" );
	
	Game.AddObjective("talkto");
		Game.AddNPC("cletus", "m2_cletus_2");
		Game.SetTalkToTarget("cletus", 0, 0); 
	Game.CloseObjective();

Game.AddStage();
	Game.SetStageMessageIndex(4);
	Game.AddObjective("dialogue");
		Game.AmbientAnimationRandomize( 1, 0 );      -- ( pc=0, npc=1) (nonrandom=0, random=1)
		Game.AmbientAnimationRandomize( 0, 0 );
		Game.SetConversationCam( 0, "pc_far" );
		Game.SetConversationCam( 1, "npc_far" );
		Game.SetConversationCam( 2, "pc_far" );
		Game.AddAmbientNpcAnimation( "none" );
		Game.AddAmbientNpcAnimation( "dialogue_no" );
		Game.AddAmbientNpcAnimation( "none" );
		Game.AddAmbientPcAnimation( "none" );
		Game.AddAmbientPcAnimation( "none" );
		Game.AddAmbientPcAnimation( "dialogue_scratch_head" );
		Game.SetCamBestSide("m3_bestside");
		Game.SetDialogueInfo("marge","cletus","allah",0);
		Game.SetDialoguePositions("m2_marge_talk","m3_cletus_walk1","m2_marge_car2");
	Game.CloseObjective();
Game.CloseStage();	

Game.CloseStage();

Game.AddStage(5)
	Game.SetStageMessageIndex(5)
	Game.AddObjective("getin", "neither")
		Game.SetObjTargetVehicle("current")
		Game.CloseObjective()
Game.CloseStage()

Game.AddStage(16)
	Game.SetStageMessageIndex(13)
	-- Game.SetHUDIcon("retire")

	Game.AddObjective("goto")
			Game.SetDestination("m1_retire", "carsphere")
			Game.AddNPC("grandpa", "m1_grandpa")
	Game.CloseObjective()


Game.CloseStage()

Game.AddStage(17);
	Game.SetStageMusicAlwaysOn()
	Game.SetMaxTraffic(3);
	Game.SetStageMessageIndex(14);
	-- Game.SetHUDIcon( "grampa" );

	Game.AddObjective("talkto")
		Game.AddNPC("grandpa", "m1_grandpa")
		Game.SetTalkToTarget("grandpa", 0, 0) 
	Game.CloseObjective()

Game.AddStage(1);
	Game.AddObjective("fmv");
		Game.SetFMVInfo("fmv4.rmv");
	Game.CloseObjective();
Game.CloseStage();

Game.AddStage(5)

	Game.SetStageMessageIndex(5)
	Game.AddObjective("getin", "neither")
		Game.SetObjTargetVehicle("current")
		Game.CloseObjective()

Game.CloseStage()


Game.AddStage(18)
	Game.SetStageMusicAlwaysOn()
	Game.SetStageMessageIndex(15)
	-- Game.SetHUDIcon("buzzcola")
	Game.SetStageTime(40)

	Game.AddObjective("delivery")
			for i = 1, ({10,10})[Difficulty.Current], 1 do
				Game.AddCollectible("buzzcola"..tostring(i),"buzzcola")
			end
	Game.CloseObjective();

	Game.AddCondition("timeout")
	Game.CloseCondition()

Game.CloseStage()

Game.AddStage("final")
	Game.SetStageMessageIndex(16)

		Game.AddObjective("goto")
			Game.SetDestination("m1_stop", "carsphere")
		Game.CloseObjective()

Game.CloseStage()

Game.CloseMission()

