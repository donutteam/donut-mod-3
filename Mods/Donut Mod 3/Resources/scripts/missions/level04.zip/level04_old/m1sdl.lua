if Settings.EnableNewLevel4Map then
	dofile(Paths.Resources .. "/scripts/missions/level04_new/" .. GetFileName(GetPath()) .. ".lua")
	return -- cancel this script
end

--Mission camera (used at beginning of mission)
Game.LoadP3DFile("art\\missions\\level01\\mission1cam.p3d")

--P3d file (contains AI car, collectible and location locators)
Game.LoadP3DFile("art\\locators\\l4m1.p3d")
	
--Mission Icons 
Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\char\\bart.p3d")