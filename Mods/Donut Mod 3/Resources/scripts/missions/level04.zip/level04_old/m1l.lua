	if Settings.EnableNewLevel4Map then
	dofile(Paths.Resources .. "/scripts/missions/level04_new/" .. GetFileName(GetPath()) .. ".lua")
	return -- cancel this script
end

--P3d file (contains AI car, collectible and location locators)
Game.LoadP3DFile("art\\locators\\l4m1.p3d")

--Collectibles
--"Mission 1"
Game.LoadP3DFile("art\\pickups\\donut_chocolate.p3d")

--"Mission 2"
Game.LoadP3DFile("art\\pickups\\lawnchair.p3d")
Game.LoadP3DFile("art\\pickups\\tombstone.p3d")
Game.LoadP3DFile("art\\pickups\\roadkill.p3d")
Game.LoadP3DFile("art\\pickups\\wooden_planks.p3d")

--"Mission 3"
Game.LoadP3DFile("art\\pickups\\ketchup.p3d")
Game.LoadP3DFile("art\\pickups\\buzzcola.p3d")

--Mission Icons
--"Mission 1"
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\location\\lardlads.p3d")
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\char\\wiggum.p3d")
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\object\\donuts.p3d")
-- Game.LoadP3DFile("art\\icons\\locations\\simpdoor.p3d")

--"Mission 2"
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\char\\cletus.p3d")
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\location\\cletushs.p3d")
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\vehicle\\cletus_v.p3d")

-- --"Mission 3"
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\object\\ketchup.p3d")
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\vehicle\\bsedan_v.p3d")
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\location\\retire.p3d")
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\object\\buzzcola.p3d")
-- Game.LoadP3DFile("art\\frontend\\dynaload\\images\\msnicons\\char\\grampa.p3d")

--"Mission 1"
Game.LoadDisposableCar("art\\cars\\wiggu_v.p3d","wiggu_v","AI")
Game.LoadDisposableCar("art\\cars\\cDonut.p3d","cDonut","AI")

--"Mission 2"
Game.LoadDisposableCar("art\\cars\\cletu_v.p3d","cletu_v","AI")

--"Mission 3"
Game.LoadDisposableCar("art\\cars\\cSedan.p3d","cSedan","AI")