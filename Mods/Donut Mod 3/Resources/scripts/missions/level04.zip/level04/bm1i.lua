Game.SelectMission("bm1")
Game.SetPresentationBitmap( "art/frontend/dynaload/images/mis04_08.p3d" )
Game.SetMissionResetPlayerInCar("bm1_carstart")
Game.SetDynaLoadData("l4r7.p3d;l4z1.p3d;l4r1.p3d;")
Game.UsePedGroup(6)

Game.AddStage(2) --Drive to the school (Skinner is outside)
	Game.RESET_TO_HERE()
	Game.SetStageMessageIndex(2)
	Game.AddStageCharacter("marge", "", "", "current", "bm1_carstart" )
	Game.SetHUDIcon( "school" )
	Game.AddObjective("goto")
	    Game.AddStageVehicle("skinn_v","skinn_v_carstart","NULL","missions\\l4bm1\\skinn_v.con","skinner")
		Game.SetDestination("bm1_school", "carsphere")
		Game.SetCollectibleEffect("wrench_collect")
	Game.CloseObjective()
	Game.SetStageTime(({60,40})[Difficulty.Current])
	Game.AddCondition("timeout")
		--Game.SetHitNRun()
	Game.CloseCondition()
Game.CloseStage()

Game.AddStage(3)--Hit Skinner's car and collect any of the intercepted gifts that fall out (5 for normal mode, 8 for hellfish)
        Game.SetStageMessageIndex(3)
        Game.SetHUDIcon("heart")
        Game.SetStageTime(240) --This is a long timer because the next stage will use the reminder of it for the next objective
        Game.ActivateVehicle("skinn_v","NULL","target")

        if Difficulty.IsHellfish then
		Game.SetVehicleAIParams("skinn_v",50,51)
	    end

		if Difficulty.IsNormal then 
		Game.SetVehicleAIParams("skinn_v",-10,-9)
		end	

		   for i = 1, 7, 1 do
			Game.AddStageWaypoint("skinn_v_waypoint"..tostring(i))
		   end
		
		Game.AddObjective("dump")
			Game.SetObjTargetVehicle("skinn_v")
		
			local Items = {"r_choco","r_dent","r_diaper","r_tomb","r_onions","cpill","bloodbag","folder"}
			for i = 1, ({5,8})[Difficulty.Current], 1 do
				Game.AddCollectible("bm1_object"..tostring(i),Items[math.random(#Items)])
			end
		Game.CloseObjective()

        Game.AddCondition("timeout")
		--Game.SetHitNRun()
	Game.CloseCondition()

Game.AddStage(4)--Blow up Skinner's car (the time reamining from the previous stage is used for this one)
    Game.SetStageMessageIndex(4)
    Game.AddStageTime(-1)
    Game.SetHUDIcon("skinn_v")
    Game.ActivateVehicle("skinn_v","NULL","target")

    if Difficulty.IsHellfish then
    Game.SetVehicleAIParams("skinn_v",50,51)
    end

    if Difficulty.IsNormal then
    Game.SetVehicleAIParams("skinn_v",-10,-9)
    end

    Game.AddObjective("destroy")
		Game.SetObjTargetVehicle("skinn_v")
	Game.CloseObjective()
	
        for i = 1, 9, 1 do
			Game.AddStageWaypoint("skinn_v_waypointa"..tostring(i))
		end
		
	Game.ShowStageComplete()

	Game.SetCompletionDialog("ahh")

	Game.AddCondition("timeout")
	Game.CloseCondition()

Game.CloseStage()

Game.AddStage(5)--Return to Comic Book Guy
    Game.SetStageMessageIndex(5)
	Game.SetHUDIcon( "cbg" )
	Game.AddObjective( "goto" )
		Game.SetDestination( "bm_end", "carsphere")
		Game.SetCollectibleEffect("wrench_collect")
	Game.CloseObjective()
	     Game.StartCountdown("count") --Required for message to appear on screen
	  Game.AddToCountdownSequence("ERROR_MEDIA_INVALID_(PS2)",3000) --The game's TextBible has been edited so that the message in the spot "ERROR_MEDIA_INVALID_(PS2)" now says "OH WELL"
	Game.SetStageTime(40)
	Game.AddCondition("timeout")
		--Game.SetHitNRun()
	Game.CloseCondition()
Game.CloseStage()

Game.AddStage(6) --Talk to Comic Book Guy
	Game.SetStageMessageIndex(6)
	Game.SetHUDIcon( "cbg" )
	Game.AddObjective("talkto")
		Game.SetTalkToTarget("cbg", 0, 0) -- 0 - eclamation, 1 is gift, with optional hieight offset
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage("final") 
	Game.AddObjective("dialogue")
		--Game.AmbientAnimationRandomize( 1, 0 )      -- ( pc=0, npc=1) (nonrandom=0, random=1)
		--Game.AmbientAnimationRandomize( 0, 0 )
		--Game.AddAmbientNpcAnimation( "none" )
		--Game.AddAmbientNpcAnimation( "dialogue_no" )
		--Game.AddAmbientNpcAnimation( "none" )
		--Game.AddAmbientPcAnimation( "none" )
		--Game.AddAmbientPcAnimation( "none" )
		--Game.AddAmbientPcAnimation( "dialogue_scratch_head" )
		--Game.SetConversationCam( 3, "pc_far" )
		-- Game.SetCamBestSide( "bm1_bestside" )
		Game.SetDialogueInfo("cbg","marge","dead",0)
	Game.CloseObjective()
Game.CloseStage()


if Difficulty.IsHellfish then --The rest of the mission will only be started if hellfish mode is enabled

  Game.AddStage(2) --Drive to the school playground
	Game.SetStageMessageIndex(7)
	Game.SetHUDIcon( "playgrou" )
	Game.AddObjective("goto")
		Game.SetDestination("bm1_playground", "carsphere")
		Game.SetCollectibleEffect("wrench_collect")
	Game.CloseObjective()
	Game.SetStageTime(50)
	Game.AddCondition("timeout")
		--Game.SetHitNRun()
	Game.CloseCondition()
Game.CloseStage()

Game.AddStage(9) --Destroy the school playground. (triggerspheres placed over every destroyable object/any object that can be knocked over in the playground. 8 in total)
  Game.SetStageMessageIndex(8)
  Game.SetStageTime(40)
 Game.AddObjective("delivery")
	    for i = 1, 8, 1 do
				Game.AddCollectible("destroy"..tostring(i),"triggersphere")
			end
  Game.AddCondition("timeout")
	Game.CloseCondition()
  Game.CloseStage()
 

  Game.AddStage(10) --Drive to Principal Skinner's house. (the house is beside the large mansion with a gate that bumblebeeman stands outside of)
    Game.SetStageMessageIndex(9)
    Game.AddObjective("goto")
    Game.SetHUDIcon("skinnerhouse")
     Game.AddNPC("skinner","bm1_skinner") 
    Game.SetDestination("skinner_house", "carsphere")
		Game.SetCollectibleEffect("wrench_collect")
	Game.CloseObjective()
		Game.SetStageTime(30)
	Game.AddCondition("timeout")
		--Game.SetHitNRun()
	Game.CloseCondition()
  Game.CloseStage()

  Game.AddStage(11)--Run principal Skinner over. Skinner has been added to a location outside his house and a triggersphere has been placed over him
   Game.SetStageMessageIndex(10)
   Game.SetHUDIcon("skinner")
   Game.SetStageTime(5)
   Game.AddObjective("delivery")
   Game.AddCollectible("skinnerathouse","triggersphere")
   Game.CloseObjective()
   Game.AddCondition("timeout")
	Game.CloseCondition()
	Game.ShowStageComplete()
	Game.SetCompletionDialog("children", "skinner")
Game.CloseStage()

 Game.AddStage(6) --Drive to Comic Book Guy (fake objective- the player will accidently drive to an invisible locator just outside the Garage shortcut that will initiate a chase with Chief Wiggum
     Game.SetHUDIcon("cbg")
     Game.SetStageTime(25)
	 Game.SetStageMessageIndex(11)
     Game.AddStageVehicle("wiggu_v","wiggu_chase","NULL","Missions\\l4m1\\M1evade.con","wiggum")

	 Game.AddObjective("goto")
		Game.SetDestination("bm1_chase", "carsphere")
		Game.SetCollectibleEffect("wrench_collect")
	 Game.CloseObjective()

    Game.AddCondition("timeout")
	 Game.CloseCondition()

 Game.CloseStage()
  
 Game.AddStage(7)--Get away from Chief Wiggum (uses same .con file and distance from L4M1)
    Game.SetHUDIcon("wiggu_v")
    Game.SetStageTime(30)
	Game.SetStageMessageIndex(12)

   Game.ActivateVehicle("wiggu_v","NULL","chase")

	Game.AddObjective("losetail")
		Game.SetObjTargetVehicle("wiggu_v")
		Game.SetObjDistance(150)
	Game.CloseObjective()

	Game.AddCondition("timeout")
	Game.CloseCondition()

	Game.ShowStageComplete()
	Game.SetCompletionDialog("taze", "wiggum")
 Game.CloseStage()	



  Game.AddStage(12)--Drive to Comic Book Guy (after getting away from Chief Wiggum)
    Game.SetStageMessageIndex(11)
	Game.SetHUDIcon( "cbg" )
	Game.AddObjective( "goto" )
		Game.SetDestination( "bm_end", "carsphere")
		Game.SetCollectibleEffect("wrench_collect")
	Game.CloseObjective()
	Game.SetStageTime(50)
	Game.AddCondition("timeout")
		--Game.SetHitNRun()
	Game.CloseCondition()
Game.CloseStage()

  Game.AddStage(13) --Talk to Comic Book Guy
	Game.SetStageMessageIndex(6)
	Game.SetHUDIcon( "cbg" )
	Game.AddObjective("talkto")
		Game.SetTalkToTarget("cbg", 0, 0) -- 0 - eclamation, 1 is gift, with optional hieight offset
	Game.CloseObjective()
Game.CloseStage()

  Game.AddStage(14,"final") --Comic Book Guy dialogue stage 
	Game.AddObjective("dialogue")
		--Game.AmbientAnimationRandomize( 1, 0 )      -- ( pc=0, npc=1) (nonrandom=0, random=1)
		--Game.AmbientAnimationRandomize( 0, 0 )
		--Game.AddAmbientNpcAnimation( "none" )
		--Game.AddAmbientNpcAnimation( "dialogue_no" )
		--Game.AddAmbientNpcAnimation( "none" )
		--Game.AddAmbientPcAnimation( "none" )
		--Game.AddAmbientPcAnimation( "none" )
		--Game.AddAmbientPcAnimation( "dialogue_scratch_head" )
		--Game.SetConversationCam( 3, "pc_far" )
		-- Game.SetCamBestSide( "bm1_bestside" )
		Game.SetDialogueInfo("marge","cbg","elf",0)
	Game.CloseObjective()
Game.CloseStage()
end

Game.CloseMission()