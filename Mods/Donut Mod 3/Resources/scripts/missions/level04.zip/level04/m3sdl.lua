LoadP3DFile("art\missions\level04\mission3cam.p3d");

LoadDisposableCar("art\cars\cletu_v.p3d","cletu_v","AI");

LoadP3DFile( "art\frontend\dynaload\images\msnicons\char\cletus.p3d" );
LoadP3DFile( "art\frontend\dynaload\images\msnicons\object\tshirt.p3d" );
LoadP3DFile( "art\frontend\dynaload\images\msnicons\vehicle\cletus_v.p3d" );