Game.SelectMission("m5")

if Difficulty.IsHellfish then
Game.SetMissionResetPlayerInCar("m5_carstart")
end

if Difficulty.IsNormal then
Game.SetMissionResetPlayerInCar("carstart_nm")  -- This is different from what it is in Hellfish Mode so Marge's car is in a better position for the first mission stage.
end

Game.SetDynaLoadData("l4z2.p3d;l4r1.p3d;l4r2.p3d;")

Game.UsePedGroup(1)
Game.AddStage(0)
	Game.SetStageMessageIndex(00)
	Game.SetHUDIcon( "car_icon" )
	Game.AddObjective("getin")
		Game.SetObjTargetVehicle("current")
	Game.CloseObjective()
	Game.SetStageTime(10)
	Game.AddCondition("timeout")Game.CloseCondition()
Game.CloseStage()

local Items = {"cola","coolr","cream","flanpic","is_comic","jeans","record"}
Game.AddStage(0) Game.RESET_TO_HERE()
	Game.SetStageMessageIndex(2)
	Game.SetHUDIcon( "b_items" )
		Game.AddObjective("delivery")
		if Difficulty.IsNormal then
			for i = 1, 20, 1 do
				Game.AddCollectible("bully_item"..tostring(i).."_n",Items[math.random(#Items)])
			end
		end		
		if Difficulty.IsHellfish then
			for i = 1, 29, 1 do
				Game.AddCollectible("bully_item"..tostring(i).."_h",Items[math.random(#Items)])
			end
		end
		Game.AddNPC("nelson", "nelson_place")
		Game.AddNPC("kearney", "kearney_place")
		Game.AddNPC("jimbo", "jimbo_place")
		Game.AddNPC("dolph", "dolph_place")
		Game.CloseObjective()
	Game.SetStageTime(({120,100})[Difficulty.Current])
	Game.AddCondition("timeout")Game.CloseCondition()
	Game.ShowStageComplete()
Game.CloseStage()

Game.AddStage(0)
	Game.SetStageMessageIndex(3)
	Game.SetHUDIcon( "nelson" )
	Game.AddObjective("talkto")
		Game.AddNPC("nelson", "nelson_place")
		Game.SetTalkToTarget("nelson", 0, 0)
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage(0)
	Game.AddObjective("dialogue")
		Game.AmbientAnimationRandomize( 1, 0 )
		Game.AmbientAnimationRandomize( 0, 0 )
		Game.SetConversationCam( 0, "pc_far" )
		Game.SetConversationCam( 1, "npc_far" )
		Game.SetConversationCam( 2, "pc_far" )
		Game.AddAmbientNpcAnimation( "none" )
		Game.AddAmbientNpcAnimation( "dialogue_no" )
		Game.AddAmbientNpcAnimation( "none" )
		Game.AddAmbientPcAnimation( "dialogue_shaking_fist" )
		Game.AddAmbientPcAnimation( "none" )
		Game.AddAmbientPcAnimation( "dialogue_hands_on_hips" )
		Game.SetConversationCam( 3, "pc_far" )
		Game.SetCamBestSide("m5_jimbo")
		Game.SetDialogueInfo("marge","nelson","hooligan",0)
		--Game.SetDialoguePositions("nelson_place","m5_kearney","m5_blacksedan_carstart")
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage(0)
	Game.SetStageMessageIndex(00)
	Game.SetHUDIcon( "car_icon" )
	Game.AddObjective("getin")
		Game.SetObjTargetVehicle("current")
	Game.CloseObjective()
	Game.SetStageTime(20)
	Game.AddCondition("timeout")Game.CloseCondition()
Game.CloseStage()

Game.AddStage(0)
	Game.SetStageMessageIndex(4)
	if Difficulty.IsNormal then
	Game.AddStageVehicle("cVan","cVan_start","target","missions\\l4m5\\cVan.con", "male3")
	end
	
	if Difficulty.IsHellfish then
	Game.AddStageVehicle("cVan","cVan_start","evade","missions\\l4m5\\cVan.con", "male3")
	end
	
	Game.SetHUDIcon("cvan_v")

	Game.AddStageWaypoint( "cVan_path1")
	Game.AddStageWaypoint( "cVan_path2")
	Game.AddStageWaypoint( "cVan_path3")
	
	Game.SetVehicleAIParams( "cVan", 50, 51 )
	Game.SetStageAIRaceCatchupParams("cVan", 80, 0.9, 1.1, 2.2) 
	
	Game.AddObjective("follow","neither")
		Game.SetObjTargetVehicle("cVan")
		Game.AddStageVehicle("cSedan","cSedan_start","NULL","missions\\l4m5\\cSedan" .. tostring(Difficulty.Current) .. ".con", "male1")
	Game.CloseObjective()
	
	Game.AddCondition("followdistance")
		Game.SetFollowDistances(0,({180,160})[Difficulty.Current])
		Game.SetCondTargetVehicle("cVan")
	Game.CloseCondition()
Game.CloseStage()

Game.AddStage(0)
	Game.SetHUDIcon("pills")
	Game.SetStageMessageIndex(5)
	Game.ActivateVehicle("cSedan","NULL","target")
	
	if Difficulty.IsNormal then
	Game.AddStageWaypoint( "cSedan_path1_n")
	Game.AddStageWaypoint( "cSedan_path2_n")
	Game.AddStageWaypoint( "cSedan_path3_n")
	Game.AddStageWaypoint( "cSedan_path4_n")
	Game.AddStageWaypoint( "cSedan_path5_n")
	end
	
	if Difficulty.IsHellfish then
	Game.AddStageWaypoint( "cSedan_path1_h")
	Game.AddStageWaypoint( "cSedan_path2_h")
	Game.AddStageWaypoint( "cSedan_path3_h")
	Game.AddStageWaypoint( "cSedan_path4_h")
	Game.AddStageWaypoint( "cSedan_path5_h")
	end
	
	Game.AddObjective("dump", "neither")
	Game.SetObjTargetVehicle("cSedan")
	for i = 1, ({12,18})[Difficulty.Current], 1 do
		Game.AddCollectible("pills_item"..tostring(i),"pills")
	end
	Game.CloseObjective()
	
	Game.SetStageTime(185)
	Game.AddCondition("timeout")Game.CloseCondition()
Game.CloseStage()

Game.AddStage()
Game.SetStageMessageIndex(6)
	Game.SetHUDIcon("bsedan_v")
	Game.ActivateVehicle("cSedan","NULL","chase")
	Game.AddObjective("losetail")
		Game.SetObjTargetVehicle("cSedan")
		Game.SetObjDistance(({150,215})[Difficulty.Current])
	Game.CloseObjective()
	Game.SetStageTime(130)
	Game.AddCondition("timeout")Game.CloseCondition()
	Game.ShowStageComplete()
Game.CloseStage()

Game.AddStage(0)
	Game.SetStageMessageIndex(7)
	Game.SetHUDIcon( "retire" )
	Game.AddObjective( "goto" )
		Game.AddNPC("grandpa", "m5_grampa_sd")
		Game.SetDestination( "m5_castle", "carsphere")
		Game.SetCollectibleEffect("wrench_collect")
	Game.CloseObjective()
	if Difficulty.IsHellfish then
	Game.SetStageTime(110)
	Game.AddCondition("timeout")
	Game.CloseCondition()
	end
	Game.ShowStageComplete()
Game.CloseStage()

Game.AddStage(25)
	Game.SetStageMessageIndex(8)
	Game.SetHUDIcon( "grampa" )
	Game.AddObjective("talkto")
		Game.AddNPC("grandpa", "m5_grampa_sd") 
		Game.SetTalkToTarget("grandpa", 0, 0) 
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage(0)
	Game.AddObjective("dialogue")
		Game.AmbientAnimationRandomize( 1, 0 )
		Game.AmbientAnimationRandomize( 0, 0 )
		Game.SetConversationCam( 0, "pc_far" )
		Game.SetConversationCam( 1, "npc_far" )
		Game.SetConversationCam( 2, "pc_far" )
		Game.AddAmbientNpcAnimation( "none" )
		Game.AddAmbientNpcAnimation( "dialogue_no" )
		Game.AddAmbientNpcAnimation( "none" )
		Game.AddAmbientPcAnimation( "dialogue_shake_hand_in_air" )
		Game.AddAmbientPcAnimation( "none" )
		Game.AddAmbientPcAnimation( "dialogue_scratch_head" )
		Game.SetConversationCam( 3, "pc_far" )
		Game.SetCamBestSide("m5_bestside2")
		Game.SetDialogueInfo("marge","grandpa","medicine",0)
		Game.SetDialoguePositions("m5_marge_start","m5_grampa_sd","m5_carstart")
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage(1)
	Game.AddObjective("fmv")
		Game.SetFMVInfo("fmv4.rmv")
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage("final")
	Game.AddObjective("timer")
		Game.AddNPC("grandpa", "nelson_place")
		Game.SetDurationTime(1)
	Game.CloseObjective()
Game.CloseStage()

Game.CloseMission()