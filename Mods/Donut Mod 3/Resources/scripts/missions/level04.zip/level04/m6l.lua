for k, File in pairs({
-- Locators
	"art\\missions\\l4m6\\locators.p3d",
-- Mission Icons
	"art\\frontend\\dynaload\\images\\msnicons\\location\\school.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\location\\lardlads.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\location\\grocery.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\char\\bart.p3d",
	"art\\icons\\items\\sodamach.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\char\\wiggum.p3d",
-- Items
	"art\\missions\\l4m6\\i_soda.p3d",
	"art\\missions\\l4m6\\sodamach.p3d",
}) do
	Game.LoadP3DFile(File)
end

for k, DisposableCar in pairs({
	{"art\\cars\\wiggu_v.p3d","wiggu_v","OTHER"},
	{"art\\cars\\honor_v.p3d","honor_v","AI"},
}) do
	Game.LoadDisposableCar(table.unpack(DisposableCar))
end