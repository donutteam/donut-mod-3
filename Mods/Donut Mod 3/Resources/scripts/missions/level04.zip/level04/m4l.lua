for k, File in pairs({
	"art\\missions\\l4m4\\locators.p3d",
	"art\\missions\\l4m4\\key.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\location\\retire.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\vehicle\\wiggu_v.p3d",
	"art\\missions\\generic\\fline.p3d",
	"art\\icons\\cars\\car_icon.p3d",
	"art\\icons\\chars\\lou.p3d",
	"art\\icons\\chars\\eddie.p3d",
}) do
	Game.LoadP3DFile(File)
end

for k, DisposableCar in pairs({
	{"art\\cars\\wiggu_v.p3d","wiggu_v","AI"},
	{"art\\cars\\lou_v.p3d","lou_v","AI"},
	{"art\\cars\\eddie_v.p3d","eddie_v","AI"},
}) do
	Game.LoadDisposableCar(table.unpack(DisposableCar))
end