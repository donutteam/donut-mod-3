for k, File in pairs({
	-- Locators
	"art\\missions\\l4m7\\locators.p3d",
	
	-- Mission Icons
	"art\\frontend\\dynaload\\images\\msnicons\\location\\kwike.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\char\\frink.p3d",
}) do
	Game.LoadP3DFile(File)
end