Game.SelectMission("m4")
	Game.SetMissionResetPlayerOutCar("m4_marge_start","m4_carstart")
	Game.SetDynaLoadData("l4z1.p3d;l4z7.p3d;l4r7.p3d;")
	Game.UsePedGroup(6)

	Game.AddStage(0) Game.RESET_TO_HERE() --Getting into your vehicle to start the race.
		Game.SetHUDIcon("car_icon")
		Game.SetStageMessageIndex(3)
		Game.SetStageTime(({20,10})[Difficulty.Current])
		
		Game.AddObjective("getin")
			Game.SetObjTargetVehicle("current")
			
			Game.AddStageVehicle("wiggu_v","wiggum_start","NULL","missions\\l4m4\\wiggu_v"..tostring(Difficulty.Current)..".con","wiggum")
			Game.AddStageVehicle("lou_v","lou_start","NULL","missions\\l4m4\\lou_v"..tostring(Difficulty.Current)..".con", "lou")
			-- Game.AddStageVehicle("cPolice","eddie_start","NULL","Missions\\level04\\M4race.con", "eddie")
		Game.CloseObjective()
		
		Game.AddCondition("timeout") Game.CloseCondition()
	Game.CloseStage()

	Game.AddStage()
		Game.SetHUDIcon("retire")
		Game.SetStageMessageIndex(4)
		Game.SetStageTime(({45,28})[Difficulty.Current])
		Game.SetMaxTraffic(({3,5})[Difficulty.Current])
		
		Game.AddObjective("goto")
			Game.SetDestination("race_finish","carsphere")
		Game.CloseObjective()
		
		Game.AddCondition("timeout") Game.CloseCondition()
		
		Game.StageStartMusicEvent("M4_drama")
	Game.CloseStage()


	Game.AddStage()
		Game.SetHUDIcon("wiggu_v")
		Game.SetStageMessageIndex(5)
		Game.SetStageTime(180)
		
		Game.SetMaxTraffic(({2,5})[Difficulty.Current])

		Game.ActivateVehicle("wiggu_v","NULL","target")
		Game.SetStageAIRaceCatchupParams("wiggu_v", 80, 0.9, 1.5, 2.3) 
		Game.SetVehicleAIParams( "wiggu_v", -50, -49)   -- no shortcuts
		
		Game.ActivateVehicle("lou_v","NULL","chase")
		-- Game.SetStageAIRaceCatchupParams("lou_v", 80, 0.9, 1.5, 2.3) 
		-- Game.SetVehicleAIParams( "lou_v", -50, -49)   -- no shortcuts
		
		for i = 1, 8, 1 do
			
			-- 5 is the waypoint right near that shortcut near the u-turn with the tree. Marking this in case Wiggum still acts dumb here.
			-- 8 is the power plant parking lot.
		
			Game.AddStageWaypoint("wig_path_" .. tostring(i))
		end
		
		Game.AddObjective("dump")
			Game.SetObjTargetVehicle("wiggu_v")
			Game.AddCollectible("key_item","key")
		Game.CloseCondition()

		Game.AddCondition("timeout") Game.CloseCondition()
		Game.AddCondition("followdistance")
			Game.SetFollowDistances(0, ({150,120})[Difficulty.Current])
			Game.SetCondTargetVehicle("wiggu_v")
		Game.CloseCondition()
	Game.CloseStage()

	Game.AddStage()
		Game.SetHUDIcon("lou")
		Game.SetStageMessageIndex(6)
		
		Game.ActivateVehicle("lou_v","NULL","race")
		Game.SetStageAIRaceCatchupParams("lou_v", 80, 0.9, 1.5, 2.3) 
		Game.SetVehicleAIParams("lou_v", -50, -49)

		Game.AddStageWaypoint("race_finish2")

		Game.AddObjective("race")
			Game.AddNPC("grandpa", "m5_grampa_sd") 
			Game.AddCollectible("race_finish2","carsphere")
		Game.CloseObjective()
	Game.CloseStage()


	Game.AddStage()
		Game.SetHUDIcon("eddie")
		Game.SetStageMessageIndex(7)
		Game.SetStageTime(40)

		Game.AddStageVehicle("eddie_v","eddie_start","chase","missions\\l4m4\\eddie_v"..tostring(Difficulty.Current)..".con", "eddie") 

		Game.AddObjective("losetail")
			Game.SetObjTargetVehicle("eddie_v")
			Game.SetObjDistance(({140,190})[Difficulty.Current])
		Game.CloseObjective()

		Game.AddCondition("timeout") Game.CloseCondition()
		
		Game.ShowStageComplete()
	Game.CloseStage()

	Game.AddStage()
		Game.SetHUDIcon("retire")
		Game.SetStageMessageIndex(8)

		if Difficulty.IsHellfish then Game.SetStageTime(100) end

		Game.AddObjective("goto")
			Game.SetDestination("race_finish2","carsphere")
		Game.CloseObjective()

		if Difficulty.IsHellfish then Game.AddCondition("timeout") Game.CloseCondition() end
	Game.CloseStage()
	
	Game.AddStage() --Game.RESET_TO_HERE()
	Game.SetHUDIcon("retire")
	Game.SetStageMessageIndex(9)
	
	Game.AddObjective("goto")
		Game.TurnGotoDialogOff()
		Game.SetDestination("unlock_door", "triggersphere")
		Game.SetCollectibleEffect("wrench_collect")
		Game.MustActionTrigger()
	Game.CloseObjective()
	Game.SetFadeOut(1.0)
	
	Game.CloseStage()
	
	Game.AddStage("final")
	
	Game.AddObjective("timer")
		Game.AddStageCharacter( "marge", "marge_unlock", "", "current", "m5_carstart" )
		Game.AddNPC("grandpa", "m5_grampa_sd") 
		Game.SetDurationTime(3)
	Game.CloseObjective()
	Game.CloseStage()
	
Game.CloseMission()