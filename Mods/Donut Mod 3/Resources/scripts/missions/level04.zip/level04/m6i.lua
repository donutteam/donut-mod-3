Game.SelectMission("m6")
	Game.SetMissionResetPlayerInCar("m6sd_wig_car")
	Game.SetDynaLoadData("l4z1.p3d;l4r1.p3d;l4r7.p3d;")
	Game.UsePedGroup(3)
	Game.SetNumValidFailureHints(5)
	
	Game.InitLevelPlayerVehicle("wiggu_v","m6sd_wig_car","OTHER")
	
	Game.SetForcedCar()

	Game.AddStage(0) 
		Game.RESET_TO_HERE()
		Game.SetHUDIcon("bart")
		Game.SetStageMessageIndex(6) -- Go to the Kwik-e-mart to find Bart
		Game.SetStageTime(({40,25})[Difficulty.Current])
		
		Game.AddObjective("goto")
			Game.SetDestination("m6_kwike","carsphere")
		Game.CloseObjective()
		
		Game.AddCondition("timeout") Game.CloseCondition()
		Game.AddCondition("outofvehicle")
			Game.SetCondTime(10000)
		Game.CloseCondition()
	Game.CloseStage()

	Game.AddStage(0) 
		Game.SetHUDIcon("bart")
		Game.SetStageMessageIndex(7) -- Go to the Krusty Burger to find Bart
		Game.SetStageTime(({45,30})[Difficulty.Current])

		Game.AddObjective("goto")
			Game.AddStageVehicle("honor_v","m6_bart_v","NULL","Missions\\l4m6\\Bart.con","bart")
			Game.SetDestination("m6_bart_loc","carsphere")
		Game.CloseObjective()
		
		Game.AddCondition("timeout") Game.CloseCondition()
		Game.AddCondition("outofvehicle")
			Game.SetCondTime(10000)
		Game.CloseCondition()
	Game.CloseStage()

	Game.AddStage(0)
		Game.SetHUDIcon("bart")
		Game.SetStageMessageIndex(8)
		Game.SetMaxTraffic(2)
		
		Game.ActivateVehicle("honor_v","NULL","evade")
		Game.SetVehicleAIParams("honor_v",50,51)
		
		for i=1, 10, 1 do
			Game.AddStageWaypoint("m6_b_"..tostring(i))
		end
		
		
		Game.AddObjective("dump")
			Game.SetObjTargetVehicle("honor_v")
			Game.AddCollectible("i_soda_1","i_soda") Game.BindCollectibleTo(0,0)
			Game.AddCollectible("i_soda_2","i_soda") Game.BindCollectibleTo(1,4)
			Game.AddCollectible("i_soda_3","i_soda") Game.BindCollectibleTo(2,9)
		Game.CloseObjective()
		
		Game.AddCondition("followdistance")
			Game.SetFollowDistances(0,({250,150})[Difficulty.Current])
			Game.SetCondTargetVehicle("honor_v")
		Game.CloseCondition()
		Game.AddCondition("outofvehicle")
			Game.SetCondTime(10000)
		Game.CloseCondition()
	Game.CloseStage()

	Game.AddStage(0)
		Game.SetHUDIcon("sodamach")
		Game.SetStageMessageIndex(9)
		Game.SetStageTime(({50,35})[Difficulty.Current])
		
		Game.AddObjective("delivery")
			for i = 1, 6, 1 do
				Game.AddCollectible("mach_"..tostring(i),"sodamach")
			end
		Game.CloseObjective()

		Game.AddCondition("timeout") Game.CloseCondition()
		Game.AddCondition("outofvehicle")
			Game.SetCondTime(10000)
		Game.CloseCondition()
	Game.CloseStage()

	Game.AddStage(0)
		Game.SetStageTime(3)
		Game.AddObjective("timer") Game.CloseObjective()
		Game.SetFadeOut(1.0)	
		Game.SwapInDefaultCar()
		Game.SetSwapDefaultCarLocator("m6_place_car")
		Game.SetSwapForcedCarLocator("m6_place_forced")
		Game.SetSwapPlayerLocator("m6_marge_end")

		-- Game.SetCompletionDialog("mpickle") -- marge in a pickle dialog
	Game.CloseStage()

	Game.AddStage("final")
		Game.SetStageTime(1)
		Game.AddObjective("timer") Game.CloseObjective()
	Game.CloseStage()

Game.CloseMission()