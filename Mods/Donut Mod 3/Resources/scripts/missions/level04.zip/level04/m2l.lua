for k, File in pairs({
	"art\\missions\\l4m2\\locators.p3d",

	"art\\frontend\\dynaload\\images\\msnicons\\location\\pwrplant.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\vehicle\\cletus_v.p3d",
	"art\\missions\\generic\\fline.p3d",
}) do
	Game.LoadP3DFile(File)
end

Game.LoadDisposableCar("art\\cars\\cSedan.p3d","cSedan","AI")