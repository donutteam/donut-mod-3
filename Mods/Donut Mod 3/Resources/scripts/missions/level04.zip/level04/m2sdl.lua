for k, File in pairs({
	"art\\missions\\level04\\mission2cam.p3d",

	"art\\missions\\l4m2\\locators.p3d",

	"art\\frontend\\dynaload\\images\\msnicons\\location\\cletushs.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\vehicle\\sports_v.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\location\\simpsons.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\object\\photo.p3d",
	"art\\missions\\level01\\flanpic.p3d",
}) do
	Game.LoadP3DFile(File)
end

for k, DisposableCar in pairs({
	{"art\\cars\\cletu_v.p3d","cletu_v","AI"},
	{"art\\cars\\apu_v.p3d","apu_v","AI"},
	{"art\\cars\\cSedan.p3d","cSedan","AI"},
}) do
	Game.LoadDisposableCar(table.unpack(DisposableCar))
end