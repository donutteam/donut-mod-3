for k, File in pairs({
	-- Locators
	"art\\missions\\l4m6\\locators.p3d",
	
	-- Mission Icons
	"art\\frontend\\dynaload\\images\\msnicons\\char\\grampa.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\location\\school.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\char\\bart.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\object\\tshirt.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\char\\wiggum.p3d",
}) do
	Game.LoadP3DFile(File)
end

Game.LoadDisposableCar("art\\cars\\wiggu_v.p3d","wiggu_v","AI")