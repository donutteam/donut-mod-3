for k, File in pairs({
	"art\\missions\\level04\\mission4cam.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\char\\moleman.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\location\\cemetery.p3d",
}) do
	Game.LoadP3DFile(File)
end