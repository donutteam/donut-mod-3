Game.SelectMission("m2")

Game.SetMissionResetPlayerInCar("m2_carstart")
Game.SetDynaLoadData("l4z7.p3d;l4r6.p3d;l4r7.p3d;")

Game.UsePedGroup(6)


Game.AddStage("final")
    Game.RESET_TO_HERE()

	Game.AddStageCharacter("marge", "", "", "current", "m2_carstart" )
	Game.SetStageMessageIndex(100)
	Game.SetHUDIcon("prwplant")

	Game.AddStageMusicChange()
    Game.StageStartMusicEvent("M5_start")
	
	Game.AddStageVehicle("cSedan","m2_sedan_sd","race","Missions\\l4m1\\M2chase.con")
	
	Game.SetVehicleAIParams( "cSedan", 51, 50 ) 

	Game.AddStageWaypoint( "m2_race_waypoint1" )  
	Game.AddStageWaypoint( "m2_race_waypoint2" )  
	Game.AddStageWaypoint( "m2_race_finish" )

	Game.StartCountdown("count")
			Game.AddToCountdownSequence("3",1500) 
			Game.AddToCountdownSequence("2",900) 
			Game.AddToCountdownSequence("1",1000) 
			Game.AddToCountdownSequence("GO",400) 

	Game.AddObjective( "race" )
		Game.AddCollectible("m2_race_finish","finish_line")
	Game.CloseObjective()

	Game.AddCondition("race")
		Game.SetCondTargetVehicle("cSedan")

	Game.CloseCondition()
Game.CloseStage()

Game.CloseMission()

