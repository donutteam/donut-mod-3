Game.SetPresentationBitmap("art/banners/l4r3bnnr.p3d")

for k, File in pairs({
	"art\\missions\\generic\\fline.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\object\\race.p3d",
	
	"art\\missions\\l4sr3\\locators.p3d",
	"art\\icons\\cars\\rocke_v.p3d"
}) do
	Game.LoadP3DFile(File)
end

Game.LoadDisposableCar("art\\cars\\rocke_v.p3d","rocke_v","OTHER")