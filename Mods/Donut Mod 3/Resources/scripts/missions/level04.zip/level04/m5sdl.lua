for k, File in pairs({
	"art\\missions\\l4m5\\locators.p3d", -- These are loaded simply for the carstart_nm locator. Don't remove!
	"art\\frontend\\dynaload\\images\\msnicons\\char\\grampa.p3d",
}) do
	Game.LoadP3DFile(File)
end