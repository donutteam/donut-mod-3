for k, File in pairs({
	"art\\missions\\l4bm1\\locators.p3d",
	"art\\missions\\l4bm1\\r_choco.p3d",
	"art\\missions\\l4bm1\\r_dent.p3d",
	"art\\missions\\l4bm1\\r_diaper.p3d",
	"art\\missions\\l4bm1\\r_onions.p3d",
	"art\\missions\\l4bm1\\r_tomb.p3d",
	"art\\missions\\l4bm1\\bloodbag.p3d",
	"art\\missions\\l4bm1\\cpill.p3d",
	"art\\missions\\l4bm1\\folder.p3d",

	"art\\frontend\\dynaload\\images\\msnicons\\location\\school.p3d" ,
	"art\\frontend\\dynaload\\images\\msnicons\\location\\playgrou.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\vehicle\\skinn_v.p3d" ,
	"art\\frontend\\dynaload\\images\\msnicons\\vehicle\\wiggu_v.p3d" ,
	"art\\frontend\\dynaload\\images\\msnicons\\char\\cbg.p3d" ,
	"art\\frontend\\dynaload\\images\\msnicons\\char\\skinner.p3d" ,	
	"art\\frontend\\dynaload\\images\\msnicons\\object\\heart.p3d",
	"art\\icons\\locations\\skinnerhouse.p3d",
}) do
	Game.LoadP3DFile(File)
end

for k, DisposableCar in pairs({
-- 	{"art\\cars\\macbg_v.p3d","macbg_v","OTHER"}, Refer to info.lua for why this is commented out.
	{"art\\cars\\skinn_v.p3d","skinn_v","AI"},
	{"art\\cars\\wiggu_v.p3d","wiggu_v","AI"},
}) do
	Game.LoadDisposableCar(table.unpack(DisposableCar))
end