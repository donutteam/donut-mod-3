for k, File in pairs({
	"art\\missions\\l4m5\\locators.p3d",
	"art\\missions\\l4m5\\cola.p3d",
	"art\\missions\\l4m5\\coolr.p3d",
	"art\\missions\\l4m5\\cream.p3d",
	"art\\missions\\l4m5\\flanpic.p3d",
	"art\\missions\\l4m5\\is_comic.p3d",
	"art\\missions\\l4m5\\jeans.p3d",
	"art\\missions\\l4m5\\record.p3d",
	"art\\missions\\level04\\pills.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\char\\nelson.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\location\\retire.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\object\\pills.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\vehicle\\cvan_v.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\vehicle\\bsedan_v.p3d",
	"art\\frontend\\dynaload\\images\\msnicons\\char\\grampa.p3d",
	"art\\icons\\cars\\car_icon.p3d",
	"art\\icons\\items\\b_items.p3d",
}) do
	Game.LoadP3DFile(File)
end

for k, DisposableCar in pairs({
	{"art\\cars\\cSedan.p3d","cSedan","AI"},
	{"art\\cars\\cVan.p3d","cVan","AI"},
	{"art\\cars\\snake_v.p3d","snake_v","AI"},
}) do
	Game.LoadDisposableCar(table.unpack(DisposableCar))
end
