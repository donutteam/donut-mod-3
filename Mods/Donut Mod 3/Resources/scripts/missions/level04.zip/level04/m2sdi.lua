Game.SelectMission("m2sd")
	
Game.SetMissionStartCameraName( "mission2camShape" )
Game.SetMissionStartMulticontName( "mission2cam" )
Game.SetAnimatedCameraName( "mission2camShape" )
Game.SetAnimCamMulticontName( "mission2cam" )

Game.SetMissionResetPlayerOutCar("m2_marge_start","m2_carstart")
Game.SetDynaLoadData("l4z7.p3d;l4r6.p3d;l4r7.p3d;")

Game.UsePedGroup(6)

Game.AddStage(0)
	Game.SetMaxTraffic(3)
	Game.SetStageMessageIndex(215)
	Game.SetHUDIcon( "cletushs" )
	Game.AddObjective("goto")
		Game.AddNPC("cletus","m2_cletus")
		Game.AddObjectiveNPCWaypoint( "cletus", "m2_cletus_walk1" )
		Game.AddObjectiveNPCWaypoint( "cletus", "m2_cletus" )
		Game.AddStageVehicle("cletu_v","m2_cletustruck_sd","NULL","Missions\\level04\\M2chase.con")
		Game.SetDestination("m2_locator_sd", "carsphere")
		Game.SetCollectibleEffect("wrench_collect")
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage(0)
	Game.RESET_TO_HERE()
	Game.SetStageMessageIndex(25)
	Game.SetHUDIcon( "cletus" )
	Game.AddObjective("talkto")
		Game.AddNPC("cletus","m2_cletus")
		Game.AddStageVehicle("cletu_v","m2_cletustruck_sd","NULL","Missions\\level04\\M2chase.con")
		Game.AddObjectiveNPCWaypoint( "cletus", "m2_cletus_walk1" )
		Game.SetTalkToTarget( "cletus", 0, 0)
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage(0)
	Game.AddObjective("dialogue")
		Game.SetPresentationBitmap( "art\\frontend\\dynaload\\images\\mis04_02.p3d" )
		Game.AmbientAnimationRandomize( 1, 0 )      --( pc=0, npc=1) (nonrandom=0, random=1)
		Game.AmbientAnimationRandomize( 0, 0 )
		Game.SetConversationCam( 0, "pc_far" )
		Game.SetConversationCam( 1, "npc_far" )
		Game.SetConversationCam( 2, "pc_far" )
		Game.AddAmbientNpcAnimation( "none" )
		Game.AddAmbientNpcAnimation( "dialogue_no" )
		Game.AddAmbientNpcAnimation( "none" )
		Game.AddAmbientPcAnimation( "dialogue_shake_hand_in_air" )
		Game.AddAmbientPcAnimation( "none" )
		Game.AddAmbientPcAnimation( "dialogue_hands_in_air" )
		Game.SetCamBestSide("m2_bestside")
		Game.SetDialogueInfo("marge","cletus","decrapitude",0)
		Game.SetDialoguePositions("m2_marge","m2_cletus_walk1","m2_carstart")
	Game.CloseObjective()
Game.CloseStage()

Game.AddStage()
	Game.SetStageMessageIndex(45)
	Game.SetHUDIcon( "photo" )	
	Game.AddObjective("goto")
		Game.SetDestination("m2_photo","flanpic")
	Game.CloseObjective()
	Game.ShowStageComplete()
Game.CloseStage()

Game.AddStage(0)
	Game.SetMaxTraffic(3)
	Game.SetStageMessageIndex(215)
	Game.SetHUDIcon( "cletushs" )
	Game.AddObjective("goto")
		Game.AddNPC("cletus","m2_cletus")
		Game.AddObjectiveNPCWaypoint( "cletus", "m2_cletus_walk1" )
		Game.AddObjectiveNPCWaypoint( "cletus", "m2_cletus" )
		Game.AddStageVehicle("cletu_v","m2_cletustruck_sd","NULL","Missions\\level04\\M2chase.con")
		Game.SetDestination("m2_locator_sd", "carsphere")
		Game.SetCollectibleEffect("wrench_collect")
	Game.CloseObjective()
Game.CloseStage()

Game.CloseMission()

--dialogue_hands_in_air
--dialogue_hands_on_hips
--dialogue_scratch_head
--dialogue_shaking_fist
--dialogue_thinking
--dialogue_yes
--dialogue_no
--dialogue_cross_arms
--dialogue_open_arm_hand_gesture
--dialogue_shake_hand_in_air

