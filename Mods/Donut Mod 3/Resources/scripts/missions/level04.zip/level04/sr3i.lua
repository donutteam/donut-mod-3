Game.SelectMission("sr3")
	Game.SetMissionResetPlayerInCar("rocke_v_carstart")
	Game.SetDynaLoadData("l4z2.p3d;l4r2.p3d;l4z3.p3d;")
	Game.UsePedGroup(5)

	Game.InitLevelPlayerVehicle("rocke_v","rocke_v_carstart","OTHER")
	Game.SetForcedCar()
	
	Game.AddStage(1)	Game.RESET_TO_HERE()
		Game.SetHUDIcon("rocke_v")
		Game.SetStageTime(({230,330})[Difficulty.Current]) 
		Game.SetStageMessageIndex(({1,2})[Difficulty.Current])
		if Difficulty.IsNormal then
			Game.DisableHitAndRun()
			Game.NoTrafficForStage()
		end
		
		Game.StartCountdown("count")
			Game.AddToCountdownSequence("6",1000)
			Game.AddToCountdownSequence("12",1000)
			Game.AddToCountdownSequence("1",900)
			Game.AddToCountdownSequence("GO",400)
			
		Game.AddObjective("race","neither")
			for i = 1, 10, 1 do
				Game.AddCollectible("waypoint"..tostring(i),"carsphere")
			end
			Game.SetRaceLaps(({1,2})[Difficulty.Current])
		Game.CloseObjective()
		
		Game.AddCondition("timeout") Game.CloseCondition()
		Game.AddCondition("outofvehicle")
			Game.SetCondTime(({10000,0})[Difficulty.Current])	-- No wrenches for you hellfish players.
		Game.CloseCondition()
		
		Game.ShowStageComplete()
	Game.CloseStage()
	
	Game.AddStage(1)
		Game.AddStageCharacter("marge","marge_hide","","rocke_vI","rocke_v_hide")
	
		Game.AddObjective("timer")
			Game.StayInBlack()
			Game.SetDurationTime(1)
		Game.CloseObjective()
	Game.CloseStage()
	
	Game.AddStage("final")
		Game.AddObjective("dialogue")
			Game.AddNPC("patty","patty_success")
			Game.AddNPC("selma","selma_success")
			Game.SetDialogueInfo("patty","marge","success",0)
			Game.SetDialoguePositions("patty_success","marge_success","rocke_v_hide")
		Game.CloseObjective()
	Game.CloseStage()
Game.CloseMission()