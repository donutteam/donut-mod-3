LoadP3DFile("art\missions\level04\m3.p3d");

LoadDisposableCar("art\cars\cSedan.p3d","cSedan","AI");
LoadDisposableCar("art\cars\cletu_v.p3d","cletu_v","OTHER");
LoadP3DFile("art\missions\level04\ketchup.p3d"); 

LoadP3DFile( "art\frontend\dynaload\images\msnicons\object\ketchup.p3d" );
LoadP3DFile( "art\frontend\dynaload\images\msnicons\location\cletushs.p3d" );
LoadP3DFile( "art\frontend\dynaload\images\msnicons\char\cletus.p3d" );
LoadP3DFile( "art\frontend\dynaload\images\msnicons\vehicle\wiggu_v.p3d" );

LoadP3DFile( "art\frontend\dynaload\images\msnicons\vehicle\bsedan_v.p3d" );
