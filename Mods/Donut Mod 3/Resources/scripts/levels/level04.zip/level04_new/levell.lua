-- Add Missions and Bonus Missions
for k, Mission in pairs({"m1","m2","m3","m4","m5","m6","m7","m8"}) do Game.AddMission(Mission) end
for k, BonusMission in pairs({"sr1","sr2","sr3","gr1","bm1"}) do Game.AddBonusMission(BonusMission) end

-- Load P3D Files
Game.LoadP3DFile("art\\chars\\marge_kickwave.p3d")
Game.LoadP3DFile("art\\chars\\marge_electrocuted.p3d")
Game.LoadP3DFile("art\\missions\\level04\\l4_doors.p3d")
--Game.LoadP3DFile("art\\missions\\level01\\jumps.p3d")
--Game.LoadP3DFile("art\\missions\\level04\\level.p3d")
--Game.LoadP3DFile("art\\missions\\level04\\wasps.p3d")
Game.LoadP3DFile("art\\l04_fx.p3d","GMA_LEVEL_OTHER")
--Game.LoadP3DFile("art\\missions\\generic\\sim_door.p3d")
--Game.LoadP3DFile("art\\missions\\generic\\kwk_door.p3d")
--Game.LoadP3DFile("art\\levels\\level04\\cards.p3d")
--Game.LoadP3DFile("art\\levels\\level04\\npcs.p3d")
--Game.LoadP3DFile("art\\levels\\level04\\wasps.p3d")
--Game.LoadP3DFile("art\\levels\\level04\\skinshops.p3d")

Game.LoadP3DFile("art\\map\\coin.p3d")
Game.LoadP3DFile("art\\map\\doors.p3d")
Game.LoadP3DFile("art\\map\\lights.p3d")
Game.LoadP3DFile("art\\map\\sky.p3d")
Game.LoadP3DFile("art\\locators\\l4.p3d")
	
--Game.LoadP3DFile("art\\cars\\cPolice.p3d")

-- Load Traffic P3D Files (these are randomized, so they use their own function)
--[[
LevelUtil.LoadTraffic({
	"art\\cars\\compactA.p3d",
	"art\\cars\\garbage.p3d",
	"art\\cars\\" .. (math.random(1,100) == 1 and "dtstruck" or "glastruc") .. ".p3d",
	"art\\cars\\minivanA.p3d",
	"art\\cars\\nuctruck.p3d",
	"art\\cars\\pizza.p3d",
	"art\\cars\\wagonA.p3d",
},1)
]]

Game.LoadP3DFile("art\\cars\\compactA.p3d")
Game.LoadP3DFile("art\\cars\\pickupA.p3d")
Game.LoadP3DFile("art\\cars\\sportsA.p3d")
Game.LoadP3DFile("art\\cars\\SUVA.p3d")

Game.LoadDisposableCar("art\\cars\\" .. Rewards[4].Cars[1] .. ".p3d", Rewards[4].Cars[1], "DEFAULT")

-- Load Gags
Game.ClearGagBindings() 						
--dofile(Paths.Resources .. "/scripts/levels/level04/levell.gags.interact.lua")		-- Interactive Gags (Interactive, the ones that count)
--dofile(Paths.Resources .. "/scripts/levels/level04/levell.gags.touch.lua")			-- Touch Gags (Background)

-- Suppress Drivers
for k, Driver in pairs({"marge","skinner","beeman","ralph","selma","kearney","moe","wiggum","cletus","moleman","apu","grandpa","nelson","bart"}) do
	Game.SuppressDriver(Driver)
end