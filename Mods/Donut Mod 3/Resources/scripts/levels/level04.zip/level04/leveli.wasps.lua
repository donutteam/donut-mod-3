-- Setup Wasps
Game.PreallocateActors("beecamera","2")

if Difficulty.IsNormal then
	Game.SetProjectileStats("waspray","70.0","6")
	Game.SetActorRotationSpeed("beecamera","85.0")
	Game.AddBehaviour("beecamera","ATTRACTION","6.0","12","5.0")				-- "MIN_DISTANCE","MAX_DISTANCE","SPEED"
	Game.AddBehaviour("beecamera","ATTACK_PLAYER","8.0","3.5","5.0")			-- "MAX_RANGE","FIRING_ARC","TIME"
	Game.AddBehaviour("beecamera","EVADE_PLAYER","1.0","5.0","1.0","2.0","5")	-- "MIN_DISTANCE","MAX_DISTANCE","MIN_HEIGHT","MAX_HEIGHT","SPEED"
else
	Game.SetProjectileStats("waspray","90.0","10")
	Game.SetActorRotationSpeed("beecamera","160.0")
	Game.AddBehaviour("beecamera","ATTRACTION","2.0","10","10.0")				-- "MIN_DISTANCE","MAX_DISTANCE","SPEED"
	Game.AddBehaviour("beecamera","ATTACK_PLAYER","15.0","3.0","1.0")			-- "MAX_RANGE","FIRING_ARC","TIME"
	Game.AddBehaviour("beecamera","EVADE_PLAYER","1.0","3.5","1.0","2.0","30")	-- "MIN_DISTANCE","MAX_DISTANCE","MIN_HEIGHT","MAX_HEIGHT","SPEED"
	Game.AddShield("beecamera","beeshield")
end

-- Add Wasps
Game.AddSpawnPointByLocatorScript("w_kwickemart","beecamera","Shelley","w_kwickemart","15.0","20")
Game.AddSpawnPointByLocatorScript("w_gasroof","beecamera","Shelley","w_gasroof","15.0","20")
Game.AddSpawnPointByLocatorScript("w_schoolroof1","beecamera","Shelley","w_schoolroof1","15.0","20")
Game.AddSpawnPointByLocatorScript("w_schoolroof2","beecamera","Shelley","w_schoolroof2","15.0","20")
Game.AddSpawnPointByLocatorScript("w_tower","beecamera","Shelley","w_tower","15.0","20")
Game.AddSpawnPointByLocatorScript("w_burns1","beecamera","Shelley","w_burns1","60.0","30")
Game.AddSpawnPointByLocatorScript("w_chess1","beecamera","Shelley","w_chess1","30.0","20")
Game.AddSpawnPointByLocatorScript("w_chess2","beecamera","Shelley","w_chess2","30.0","10")
Game.AddSpawnPointByLocatorScript("w_trailor1","beecamera","Shelley","w_trailor1","50.0","20")
Game.AddSpawnPointByLocatorScript("w_trailor2","beecamera","Shelley","w_trailor2","50.0","20")
Game.AddSpawnPointByLocatorScript("w_simpsons","beecamera","Shelley","w_simpsons","20.0","20")
Game.AddSpawnPointByLocatorScript("w_flanders","beecamera","Shelley","w_flanders","25.0","20")
Game.AddSpawnPointByLocatorScript("w_neighbor1","beecamera","Shelley","w_neighbor1","15.0","20")
Game.AddSpawnPointByLocatorScript("w_wiggum","beecamera","Shelley","w_wiggum","15.0","20")
Game.AddSpawnPointByLocatorScript("w_wiggum2","beecamera","Shelley","w_wiggum2","20.0","10")
Game.AddSpawnPointByLocatorScript("w_gasroof2","beecamera","Shelley","w_gasroof2","15.0","20")
Game.AddSpawnPointByLocatorScript("w_schoolstairs","beecamera","Shelley","w_schoolstairs","15.0","20")
Game.AddSpawnPointByLocatorScript("w_burns2","beecamera","Shelley","w_burns2","60.0","30")
Game.AddSpawnPointByLocatorScript("static_bee2","beecamera","Shelley","w_powerplant2","20.0","10")
Game.AddSpawnPointByLocatorScript("static_bee6","beecamera","Shelley","w_barn","20.0","20")

if not Settings.DisableNewWasps then
	Game.AddSpawnPointByLocatorScript("w_across","beecamera","Shelley","w_across","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_moleman","beecamera","Shelley","w_moleman","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_bluetruk","beecamera","Shelley","w_bluetruk","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_condos","beecamera","Shelley","w_condos","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_casanova","beecamera","Shelley","w_casanova","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_driveway","beecamera","Shelley","w_driveway","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_grocery","beecamera","Shelley","w_grocery","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_willished","beecamera","Shelley","w_willished","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_drawbridge","beecamera","Shelley","w_drawbridge","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_stairs","beecamera","Shelley","w_stairs","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_alley","beecamera","Shelley","w_alley","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_powerplant","beecamera","Shelley","w_powerplant","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_plantentry","beecamera","Shelley","w_plantentry","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_tommacosign","beecamera","Shelley","w_tommacosign","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_tirefire","beecamera","Shelley","w_tirefire","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_moes","beecamera","Shelley","w_moes","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_bridge","beecamera","Shelley","w_bridge","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_poorgas","beecamera","Shelley","w_poorgas","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_bluehouse","beecamera","Shelley","w_bluehouse","15.0","60")
	Game.AddSpawnPointByLocatorScript("w_sandbox","beecamera","Shelley","w_sandbox","15.0","60")
end